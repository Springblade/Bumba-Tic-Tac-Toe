package Tic_Tac_Toe;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.HashMap;
import java.util.Map;
import java.net.InetAddress;
import java.net.UnknownHostException;

import Tic_Tac_Toe.client.*;
import Tic_Tac_Toe.game.TicTacToe;

public class clientMain {

    private chatClient client;
    private gameClient game;

    public static void main(String[] args) {

    }

}
package Tic_Tac_Toe.common;

public interface message {
    String getType();
    String getGameId();
    String getContent();
}
